﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace INSS
{
    public class Calculo
    {

        public decimal Calcular(DateTime data, Decimal salario)
        {
            decimal desconto = 0;

            CalculadorINSS calculadora = new CalculadorINSS();
            desconto = calculadora.CalcularDesconto(data, salario);

            return desconto;
        }

        /// <summary>
        /// Carregar aliquotas por ano
        /// </summary>
        /// <param name="ano"></param>
        /// <returns></returns>
        public List<AliquotasModel> ObterAliquotas(int ano)
        {
            List<AliquotasModel> listaAliquotas = new List<AliquotasModel>();

            #region 2011
            
            listaAliquotas.Add(new AliquotasModel(2011, 0, Decimal.Parse("1.106,90"), Decimal.Parse("0,08"), Decimal.Parse("405,86")));
            listaAliquotas.Add(new AliquotasModel(2011, Decimal.Parse("1.106,91"), Decimal.Parse("1.844,83"), Decimal.Parse("0,09"), Decimal.Parse("405,86")));
            listaAliquotas.Add(new AliquotasModel(2011, Decimal.Parse("1.844,84"), Decimal.Parse("3.689,66"), Decimal.Parse("0,11"), Decimal.Parse("405,86")));
            #endregion

            #region 2012
            listaAliquotas.Add(new AliquotasModel(2012, 0, Decimal.Parse("1.000,00"), Decimal.Parse("0,07"), decimal.Parse("500")));
            listaAliquotas.Add(new AliquotasModel(2012, Decimal.Parse("1.000,01"), Decimal.Parse("1.500,00"), Decimal.Parse("0,08"), decimal.Parse("500")));
            listaAliquotas.Add(new AliquotasModel(2012, Decimal.Parse("1.500,01"), Decimal.Parse("3.000,00"), Decimal.Parse("0,09"), decimal.Parse("500")));
            listaAliquotas.Add(new AliquotasModel(2012, Decimal.Parse("3.000,01"), Decimal.Parse("4.000,00"), Decimal.Parse("0,11"), decimal.Parse("500")));
            #endregion

            return listaAliquotas.Where(x => x.Ano == ano).ToList();
        }
    }



    public class CalculadorINSS : ICalculadorInss
    {
        public decimal CalcularDesconto(DateTime data, decimal salario)
        {
            Calculo calculo = new Calculo();
            List<AliquotasModel> aliquotas = calculo.ObterAliquotas(data.Year);
            decimal desconto = 0;

            var retorno = aliquotas.Where(x => x.Ano == data.Year & (x.SalarioDe <= salario & salario <= x.SalarioAte)).FirstOrDefault();
            if (retorno == null) // nao localizou nas aliquotas (retorna o Teto)
            {
                desconto = aliquotas.Where(x => x.Ano == data.Year).FirstOrDefault().Teto;
            }
            else
            {
                desconto = retorno.Aliquota * salario;
            }

            return desconto;
        }

    }
}
