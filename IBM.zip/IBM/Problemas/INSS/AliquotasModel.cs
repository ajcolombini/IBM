﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace INSS
{
    public class AliquotasModel
    {
        public int Ano { get; set; }
        public decimal SalarioDe { get; set; }
        public decimal SalarioAte { get; set; }
        public decimal Aliquota { get; set; }
        public decimal Teto { get; set; }

        public AliquotasModel(int ano, decimal salarioDe, decimal salarioAte, decimal aliquota, decimal teto)
        {
            this.Ano = ano;
            this.SalarioDe = salarioDe;
            this.SalarioAte = salarioAte;
            this.Aliquota = aliquota;
            this.Teto = teto;
        }
    }
}
