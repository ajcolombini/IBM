﻿using System;

namespace TesteCalculoINSS
{
    class Program
    {
        static void Main(string[] args)
        {
            bool _validado = false;

            Console.WriteLine("TESTE CÁLCULO INSS");

            Console.WriteLine();
            Console.WriteLine("Informe a data (dd-mm-yyyy) 2011 a 2012:");
            string data = Console.ReadLine();

            DateTime _data;
            if (DateTime.TryParse(data, out _data))
            {
                if ((_data.Year == 2011 | _data.Year == 2012))
                {
                    _validado = true;
                    Console.WriteLine("===> data : " + _data.ToShortDateString());
                }
                else
                {
                    Console.WriteLine("===> data inválida: usar entre 2011 e 2012");
                }
            }
            else
            {
                Console.WriteLine("===> data inválida (dd-mm-yyy) entre 2011 e 2012");
            }
            Console.WriteLine();
            Console.WriteLine("Informe o salário:");
            string salario = Console.ReadLine();

            Decimal _salario;
            if (decimal.TryParse(salario, out _salario))
            {
                _validado = true;
                Console.WriteLine("===> salário : " + _salario.ToString("C"));
            }
            else
            {
                Console.WriteLine("===> Valor inválido");
            }
            Console.WriteLine();

            if (_validado)
            {
                Console.WriteLine("[Enter] Para calcular.");
                Console.ReadKey();


                INSS.Calculo calculo = new INSS.Calculo();
                decimal _desconto = calculo.Calcular(_data, _salario);

                Console.WriteLine();
                Console.WriteLine("===> Desconto: " + _desconto.ToString("C"));
                Console.WriteLine();
                Console.WriteLine();
            }



            Console.WriteLine("[Enter] Para finalizar.");
            Console.ReadLine();
        }
    }
}
